# TPMP F0 — Supabase PostgreSQL Foundation v1.0

**REVIEW ONLY — NOT DEPLOYED.** No application modules or existing database are modified by creating this archive.

## Contents
- `supabase/migrations/`: three ordered SQL migrations covering internal schemas, restricted roles, audit ledger, hash chaining, verification, retention metadata, and transactional outbox with lease fencing.
- `supabase/tests/`: SQL smoke and permission tests for a disposable database.
- `database/MIGRATION_MANIFEST.yaml`: ownership, dependencies and release gates.

## Applying in a disposable Supabase development project
1. Review all SQL, especially `SECURITY DEFINER` ownership and function grants.
2. Confirm the Supabase `extensions` schema exists and `pgcrypto` is installed there; adjust only with an explicit environment-specific migration if necessary.
3. Use a **fresh, isolated** Supabase project and apply migrations with Supabase CLI (`supabase db reset` for local development, or your reviewed migration workflow).
4. Run tests via `psql -v ON_ERROR_STOP=1 -f supabase/tests/001_f0_smoke.sql` and similarly for `002_f0_permissions.sql` against that disposable database.
5. Do not run against staging or production until all release gates pass.

## Trust boundaries
- `tpmp_event_writer`, `tpmp_outbox_worker`, `tpmp_audit_verifier` are **NOLOGIN** roles. The deployment operator must provision a separate, securely authenticated backend execution path and deliberately grant only the needed role. No browser, `anon`, `authenticated`, or `service_role` execution is granted.
- The audit append function accepts actor identity as an argument **only from a trusted backend**. F0 does not prove the actor is authenticated; that integration is a release blocker before use with real events.
- The outbox worker functions currently return only identifiers and claim tokens; a restricted payload-fetching interface and per-event-category worker authorization remain necessary before a real worker can operate.
- Audit segment creation, retention execution, external checkpoint publishing and legal-hold enforcement are **not exposed as operational APIs** in this package. F0 creates the metadata and verification primitives, but production retention operations remain disabled.
- An independent immutable checkpoint store, signing/key custody, and external verification agent are not included. PostgreSQL-only hashes do **not** prove integrity against a database superuser.
- Hash serialization version 1 uses `jsonb::text` inside a fixed event array and PostgreSQL timestamp text. Before production, pin UTC for serialization, establish canonical golden fixtures, and evaluate cross-version stability. Changing serialization requires a new format version; never silently rehash old events.
- `audit.verify_segment` validates the database's current chain head. Independent external checkpoint comparison is a separate required control.
- This is **not** a full retention or cryptographic-erasure implementation. The event payload must be strictly data-minimized; legal deletion of personal data within a hashed event requires a separately approved strategy.
- `outbox_messages` offers at-least-once processing, not exactly-once external effects. A consumer must implement its own atomic receipt/effect transaction or external idempotency.
- `outbox_delivery_attempts` is operational history, not an immutable audit ledger. Important administrative actions must also create audit events.

## Review blockers before staging
1. Run PostgreSQL/Supabase tests; SQL has **not** been executed in this environment.
2. Complete external checkpoint publisher and independently protected storage.
3. Implement trusted actor attribution and backend credential provisioning.
4. Add consumer-specific receipt and payload retrieval APIs with authorization.
5. Define audit segment provisioning/rotation and sealed-segment handling.
6. Add concurrent two-session tests, rollback tests, replay/idempotency tests, RLS and privilege integration tests.
7. Verify tenant/organization foreign keys after F1 organization tables exist.
8. Approve retention/hold execution design before enabling deletion.

## Important caveat
This is a concrete, reviewable **initial implementation**, not a security-certified or production-ready migration set. The F0 architectural specification remains authoritative if an implementation detail needs revision.
