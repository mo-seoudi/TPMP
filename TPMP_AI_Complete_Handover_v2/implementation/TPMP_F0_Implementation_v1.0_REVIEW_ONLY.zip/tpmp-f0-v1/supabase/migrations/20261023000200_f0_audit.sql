-- F0.002: audit ledger, segment serialization and verification.
CREATE TABLE audit.audit_segments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 stream_key text NOT NULL, -- platform or tenant:<uuid>, validated by trusted producer
 period_start timestamptz NOT NULL,
 period_end timestamptz NOT NULL,
 status text NOT NULL DEFAULT 'open' CHECK(status IN ('open','sealed','archived')),
 hash_format_version integer NOT NULL DEFAULT 1 CHECK(hash_format_version=1),
 hash_algorithm text NOT NULL DEFAULT 'sha256' CHECK(hash_algorithm='sha256'),
 last_sequence bigint NOT NULL DEFAULT 0 CHECK(last_sequence>=0),
 last_event_hash bytea,
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 sealed_at timestamptz,
 CONSTRAINT ck_audit_segment_period CHECK(period_end>period_start),
 CONSTRAINT uq_audit_segment UNIQUE(stream_key,period_start),
 CONSTRAINT ck_audit_segment_head CHECK((last_sequence=0 AND last_event_hash IS NULL) OR (last_sequence>0 AND octet_length(last_event_hash)=32))
);
CREATE UNIQUE INDEX idx_audit_open_stream ON audit.audit_segments(stream_key) WHERE status='open';
CREATE INDEX idx_audit_segment_period ON audit.audit_segments(stream_key,period_start DESC);
CREATE TABLE audit.audit_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 segment_id uuid NOT NULL REFERENCES audit.audit_segments(id),
 segment_sequence bigint NOT NULL CHECK(segment_sequence>0),
 organization_id uuid,
 actor_user_id uuid,
 actor_type text NOT NULL CHECK(actor_type IN ('user','system','worker','support')),
 action_code text NOT NULL CHECK(length(action_code)>0),
 module_code text NOT NULL,
 resource_type text NOT NULL,
 resource_id uuid,
 event_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
 correlation_id uuid NOT NULL,
 causation_id uuid,
 occurred_at timestamptz NOT NULL,
 recorded_at timestamptz NOT NULL,
 schema_version integer NOT NULL CHECK(schema_version>0),
 canonical_event bytea NOT NULL,
 previous_hash bytea,
 event_hash bytea NOT NULL CHECK(octet_length(event_hash)=32),
 CONSTRAINT uq_audit_event_sequence UNIQUE(segment_id,segment_sequence)
);
CREATE INDEX idx_audit_events_org_time ON audit.audit_events(organization_id,recorded_at DESC);
CREATE INDEX idx_audit_events_resource ON audit.audit_events(module_code,resource_type,resource_id,recorded_at DESC);
CREATE INDEX idx_audit_events_correlation ON audit.audit_events(correlation_id);
CREATE TABLE audit.integrity_checkpoints (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 segment_id uuid NOT NULL REFERENCES audit.audit_segments(id),
 last_verified_sequence bigint NOT NULL,
 terminal_hash bytea NOT NULL CHECK(octet_length(terminal_hash)=32),
 external_reference text,
 status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','published','verified','failed')),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 published_at timestamptz,
 UNIQUE(segment_id,last_verified_sequence)
);
CREATE TABLE audit.integrity_verification_runs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 segment_id uuid NOT NULL REFERENCES audit.audit_segments(id),
 status text NOT NULL CHECK(status IN ('passed','failed')),
 checked_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 checked_count bigint NOT NULL,
 failure_reason text
);
CREATE TABLE audit.retention_policies (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 stream_key text NOT NULL,
 event_category text NOT NULL,
 policy_version integer NOT NULL CHECK(policy_version>0),
 retention_interval interval NOT NULL CHECK(retention_interval>interval '0'),
 retention_action text NOT NULL CHECK(retention_action IN ('archive','anonymize','delete')),
 effective_from timestamptz NOT NULL,
 approved_by uuid NOT NULL,
 UNIQUE(stream_key,event_category,policy_version)
);
CREATE TABLE audit.legal_holds (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 stream_key text NOT NULL,
 segment_id uuid REFERENCES audit.audit_segments(id),
 reason text NOT NULL,
 status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','released')),
 created_by uuid NOT NULL,
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 released_at timestamptz
);
CREATE INDEX idx_audit_holds_active ON audit.legal_holds(stream_key,segment_id) WHERE status='active';
CREATE TABLE audit.retention_execution_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 segment_id uuid NOT NULL REFERENCES audit.audit_segments(id),
 retention_policy_id uuid NOT NULL REFERENCES audit.retention_policies(id),
 operation text NOT NULL CHECK(operation IN ('archive','anonymize','delete','crypto_erase')),
 executed_by uuid NOT NULL,
 executed_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 outcome text NOT NULL,
 evidence_reference text NOT NULL
);
-- These F0 objects are private. Browser roles have neither table grants nor function execution.
REVOKE ALL ON ALL TABLES IN SCHEMA audit FROM PUBLIC, anon, authenticated, service_role;
GRANT SELECT ON audit.audit_segments,audit.audit_events,audit.integrity_checkpoints TO tpmp_audit_verifier;
-- No direct writes to audit tables are granted, even to tpmp_event_writer.

-- Canonical bytes are captured at insertion. v1 serialization is explicitly versioned;
-- the verifier additionally compares event fields to these bytes on the same PG version.
CREATE FUNCTION audit.append_event(
 p_stream_key text, p_organization_id uuid, p_actor_user_id uuid,
 p_actor_type text, p_action_code text, p_module_code text,
 p_resource_type text, p_resource_id uuid, p_event_payload jsonb,
 p_correlation_id uuid, p_causation_id uuid DEFAULT NULL,
 p_schema_version integer DEFAULT 1
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, audit, extensions
SET TimeZone = 'UTC' AS $$
DECLARE s audit.audit_segments%ROWTYPE; eid uuid := gen_random_uuid();
        ts timestamptz := clock_timestamp(); seq bigint; canonical bytea; hash bytea;
BEGIN
 IF p_stream_key IS NULL OR p_stream_key !~ '^(platform|tenant:[0-9a-f-]{36})$' THEN RAISE EXCEPTION 'Invalid stream'; END IF;
 IF p_actor_type NOT IN ('user','system','worker','support') OR p_action_code IS NULL OR p_module_code IS NULL OR p_resource_type IS NULL OR p_correlation_id IS NULL OR p_schema_version<1 THEN RAISE EXCEPTION 'Invalid audit event'; END IF;
 IF p_stream_key='platform' AND p_organization_id IS NOT NULL THEN RAISE EXCEPTION 'Platform stream mismatch'; END IF;
 IF p_stream_key LIKE 'tenant:%' AND (p_organization_id IS NULL OR p_stream_key <> 'tenant:'||p_organization_id::text) THEN RAISE EXCEPTION 'Tenant stream mismatch'; END IF;
 -- Verified actor attribution is the responsibility of the trusted backend credential.
 SELECT * INTO s FROM audit.audit_segments WHERE stream_key=p_stream_key AND status='open' FOR UPDATE;
 IF NOT FOUND OR ts<s.period_start OR ts>=s.period_end THEN RAISE EXCEPTION 'No eligible open audit segment'; END IF;
 seq := s.last_sequence+1;
 canonical := convert_to(jsonb_build_array(
  1,s.id::text,seq,eid::text,p_organization_id::text,p_actor_user_id::text,
  p_actor_type,p_action_code,p_module_code,p_resource_type,p_resource_id::text,
  coalesce(p_event_payload,'{}'::jsonb),p_correlation_id::text,p_causation_id::text,
  ts::text,p_schema_version)::text,'UTF8');
 hash := extensions.digest(coalesce(s.last_event_hash,''::bytea)||canonical,'sha256');
 INSERT INTO audit.audit_events(id,segment_id,segment_sequence,organization_id,actor_user_id,actor_type,
  action_code,module_code,resource_type,resource_id,event_payload,correlation_id,causation_id,
  occurred_at,recorded_at,schema_version,canonical_event,previous_hash,event_hash)
 VALUES(eid,s.id,seq,p_organization_id,p_actor_user_id,p_actor_type,p_action_code,p_module_code,
  p_resource_type,p_resource_id,coalesce(p_event_payload,'{}'::jsonb),p_correlation_id,p_causation_id,
  ts,ts,p_schema_version,canonical,s.last_event_hash,hash);
 UPDATE audit.audit_segments SET last_sequence=seq,last_event_hash=hash WHERE id=s.id;
 RETURN eid;
END $$;
REVOKE ALL ON FUNCTION audit.append_event(text,uuid,uuid,text,text,text,text,uuid,jsonb,uuid,uuid,integer) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION audit.append_event(text,uuid,uuid,text,text,text,text,uuid,jsonb,uuid,uuid,integer) TO tpmp_event_writer;

CREATE FUNCTION audit.verify_segment(p_segment_id uuid) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,audit,extensions
SET TimeZone = 'UTC' AS $$
DECLARE s audit.audit_segments%ROWTYPE; e audit.audit_events%ROWTYPE;
 prev bytea := NULL; n bigint := 0; expected bytea; rebuilt bytea;
BEGIN
 SELECT * INTO s FROM audit.audit_segments WHERE id=p_segment_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'Segment not found'; END IF;
 FOR e IN SELECT * FROM audit.audit_events WHERE segment_id=p_segment_id ORDER BY segment_sequence LOOP
   n:=n+1;
   IF e.segment_sequence<>n OR e.previous_hash IS DISTINCT FROM prev THEN RETURN false; END IF;
   rebuilt:=convert_to(jsonb_build_array(
     1,s.id::text,n,e.id::text,e.organization_id::text,e.actor_user_id::text,
     e.actor_type,e.action_code,e.module_code,e.resource_type,e.resource_id::text,
     e.event_payload,e.correlation_id::text,e.causation_id::text,
     e.recorded_at::text,e.schema_version)::text,'UTF8');
   IF rebuilt<>e.canonical_event THEN RETURN false; END IF;
   expected:=extensions.digest(coalesce(prev,''::bytea)||e.canonical_event,'sha256');
   IF expected<>e.event_hash THEN RETURN false; END IF;
   prev:=expected;
 END LOOP;
 RETURN n=s.last_sequence AND prev IS NOT DISTINCT FROM s.last_event_hash;
END $$;
REVOKE ALL ON FUNCTION audit.verify_segment(uuid) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION audit.verify_segment(uuid) TO tpmp_audit_verifier;

CREATE FUNCTION audit.seal_segment(p_segment_id uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,audit,extensions
SET TimeZone = 'UTC' AS $$
DECLARE s audit.audit_segments%ROWTYPE;
BEGIN
 SELECT * INTO s FROM audit.audit_segments WHERE id=p_segment_id FOR UPDATE;
 IF NOT FOUND OR s.status<>'open' THEN RAISE EXCEPTION 'Not an open segment'; END IF;
 IF NOT audit.verify_segment(p_segment_id) THEN RAISE EXCEPTION 'Integrity check failed'; END IF;
 UPDATE audit.audit_segments SET status='sealed',sealed_at=clock_timestamp() WHERE id=p_segment_id;
 INSERT INTO audit.integrity_checkpoints(segment_id,last_verified_sequence,terminal_hash)
 VALUES(p_segment_id,s.last_sequence,coalesce(s.last_event_hash,extensions.digest(''::bytea,'sha256')));
END $$;
REVOKE ALL ON FUNCTION audit.seal_segment(uuid) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION audit.seal_segment(uuid) TO tpmp_audit_verifier;
