-- Run in a disposable Supabase PostgreSQL database using psql -v ON_ERROR_STOP=1.
-- Transaction rolls back fixtures. Requires privileged migration/test role.
BEGIN;
DO $$ DECLARE sid uuid; aid uuid; mid uuid; v boolean; t uuid; rid uuid;
BEGIN
 INSERT INTO audit.audit_segments(stream_key,period_start,period_end)
 VALUES('platform',clock_timestamp()-interval '1 minute',clock_timestamp()+interval '1 day') RETURNING id INTO sid;
 aid:=audit.append_event('platform',NULL,NULL,'system','f0.test','foundation','test',NULL,
  '{"ok":true}'::jsonb,gen_random_uuid());
 IF aid IS NULL OR NOT audit.verify_segment(sid) THEN RAISE EXCEPTION 'Audit append/verify failed'; END IF;
 mid:=automation.enqueue_event(NULL,'f0.test','test',gen_random_uuid(),'{"ok":true}',gen_random_uuid(),'f0-test','test-1');
 IF mid IS NULL THEN RAISE EXCEPTION 'Outbox enqueue failed'; END IF;
 SELECT message_id,claim_token INTO rid,t FROM automation.claim_messages('test-worker',1,120);
 IF rid<>mid OR NOT automation.complete_message(rid,'test-worker',t) THEN RAISE EXCEPTION 'Outbox claim/complete failed'; END IF;
 IF automation.complete_message(rid,'test-worker',t) THEN RAISE EXCEPTION 'Duplicate completion accepted'; END IF;
END $$;
ROLLBACK;
