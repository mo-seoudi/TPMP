-- Run with psql -v ON_ERROR_STOP=1. Verify ordinary roles lack table and function access.
DO $$ BEGIN
 IF has_schema_privilege('authenticated','audit','USAGE') OR has_schema_privilege('anon','automation','USAGE') THEN
  RAISE EXCEPTION 'Unexpected public schema access'; END IF;
 IF has_table_privilege('authenticated','audit.audit_events','INSERT') OR
    has_table_privilege('authenticated','audit.audit_events','UPDATE') OR
    has_table_privilege('authenticated','audit.audit_events','DELETE') THEN
  RAISE EXCEPTION 'Unexpected audit table write grant'; END IF;
 IF has_function_privilege('authenticated',
 'audit.append_event(text,uuid,uuid,text,text,text,text,uuid,jsonb,uuid,uuid,integer)','EXECUTE') THEN
  RAISE EXCEPTION 'Unexpected append execution grant'; END IF;
 IF has_function_privilege('authenticated',
 'automation.claim_messages(text,integer,integer)','EXECUTE') THEN
  RAISE EXCEPTION 'Unexpected worker execution grant'; END IF;
END $$;
